<?php

namespace App\Http\Controllers;

use App\Models\Buku;
use Illuminate\Http\Request;

class BukuController extends Controller
{
    // Menampilkan daftar buku
    public function index()
    {
        $buku = Buku::all(); // atau paginate jika kamu ingin pagination
        return view('buku', compact('buku'));
    }
   

    // Menampilkan form untuk menambah buku
    // Menampilkan form untuk menambah buku
    public function create() {
        return view('buku.create');
    }

    // Menyimpan buku ke database
    public function store(Request $request) {
        $validated = $request->validate([
            'judul' => 'required|string',
            'pengarang' => 'required|string',
            'tahun' => 'required|numeric',
            'penerbit' => 'nullable|string',
            'kategori' => 'nullable|string',
        ]);
    
        Buku::create($validated);
    
        return redirect()->route('home')->with('success', 'Buku berhasil ditambahkan');
    }
    


    // Menampilkan form untuk mengedit buku
    public function edit($id)
    {
        $buku = Buku::findOrFail($id);
        return view('buku.edit', compact('buku'));
    }
    
    // Mengupdate data buku
    public function update(Request $request, $id)
{
    // Validasi data input
    $request->validate([
        'judul' => 'required|string|max:255',
        'pengarang' => 'required|string|max:255',
        'tahun' => 'required|integer',
        'penerbit' => 'required|string|max:255',
        'kategori' => 'required|string|max:255',
    ]);

    // Cari buku berdasarkan ID
    $buku = Buku::findOrFail($id);

    // Update data buku
    $buku->update([
        'judul' => $request->judul,
        'pengarang' => $request->pengarang,
        'tahun' => $request->tahun,
        'penerbit' => $request->penerbit,
        'kategori' => $request->kategori,
    ]);

    return redirect()->route('buku.index')->with('success', 'Buku berhasil diperbarui.');
}



    // Menghapus data buku
    public function destroy($id) {
        Buku::destroy($id);
        return redirect()->route('buku.index');
    }

}
